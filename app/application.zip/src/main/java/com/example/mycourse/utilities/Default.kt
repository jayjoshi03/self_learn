package com.example.mycourse.utilities

object Default {
    const val BASE_URL = "https://gist.githubusercontent.com/akshayxunison/d026f35698e6de4ace5b350c281d4992/raw/8f1a506716440e3a96aa7914fba083aacf0e9b28/"
    const val COURSE_COLLECTION = "COURSECOLLECTION"
    const val COURSE_LIST = "COURSELIST"
    const val TITLE = "Title"
}